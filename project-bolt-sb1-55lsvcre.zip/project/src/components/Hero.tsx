import React, { useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import gsap from 'gsap';
import { ArrowDown } from 'lucide-react';

const Hero: React.FC = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLHeadingElement>(null);
  const roleRef = useRef<HTMLParagraphElement>(null);
  
  useEffect(() => {
    if (textRef.current) {
      const letters = textRef.current.textContent?.split('') || [];
      textRef.current.textContent = '';
      
      letters.forEach((letter, i) => {
        const span = document.createElement('span');
        span.textContent = letter;
        span.style.opacity = '0';
        span.style.display = letter === ' ' ? 'inline' : 'inline-block';
        span.style.transform = 'translateY(20px) rotateX(-90deg)';
        textRef.current?.appendChild(span);
      });
      
      gsap.to(textRef.current.children, {
        opacity: 1,
        y: 0,
        rotateX: 0,
        stagger: 0.05,
        duration: 0.8,
        ease: "back.out(1.7)",
        delay: 0.5
      });
    }
    
    if (roleRef.current) {
      const words = roleRef.current.textContent?.split(' ') || [];
      roleRef.current.textContent = '';
      
      words.forEach((word) => {
        const span = document.createElement('span');
        span.textContent = word + ' ';
        span.style.opacity = '0';
        span.style.display = 'inline-block';
        roleRef.current?.appendChild(span);
      });
      
      gsap.to(roleRef.current.children, {
        opacity: 1,
        y: 0,
        duration: 1,
        stagger: 0.1,
        ease: "power4.out",
        delay: 1.5
      });
    }
    
    if (heroRef.current) {
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: heroRef.current,
          start: "top top",
          end: "bottom top",
          scrub: 1
        }
      });
      
      tl.to(".parallax-bg", {
        y: 200,
        scale: 1.2,
        opacity: 0.5
      });
    }
  }, []);

  return (
    <motion.section
      id="home"
      ref={heroRef}
      className="relative min-h-screen flex items-center justify-center section-padding overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 1 }}
    >
      <div className="absolute inset-0 z-[-1] parallax-bg">
        <div className="absolute top-1/3 left-1/4 w-72 h-72 bg-primary-500/20 rounded-full filter blur-[80px] animate-pulse-slow" />
        <div className="absolute bottom-1/3 right-1/4 w-96 h-96 bg-secondary-500/20 rounded-full filter blur-[100px] animate-pulse-slow" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-accent-500/20 rounded-full filter blur-[60px] animate-pulse-slow" />
      </div>
      
      <div className="max-w-4xl mx-auto text-center relative z-10">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-lg md:text-xl mb-6 text-primary-400 font-medium tracking-wider"
        >
          Hello, I'm
        </motion.p>
        
        <h1 ref={textRef} className="text-5xl md:text-7xl lg:text-8xl font-display font-bold mb-6 perspective-text">
          Nikhil Telase
        </h1>
        
        <p ref={roleRef} className="text-2xl md:text-3xl mb-10 text-gray-300 overflow-hidden">
          Creative Developer & Designer
        </p>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <a href="#projects" className="btn-primary group">
            <span className="relative z-10">View My Work</span>
            <div className="absolute inset-0 bg-white/20 scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left rounded-md" />
          </a>
          <a 
            href="#contact" 
            className="px-6 py-3 rounded-md border border-primary-600 text-white font-medium group relative overflow-hidden"
          >
            <span className="relative z-10">Contact Me</span>
            <div className="absolute inset-0 bg-primary-600 scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left" />
          </a>
        </motion.div>
      </div>
      
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, delay: 1 }}
        className="scroll-indicator absolute bottom-10 left-1/2 transform -translate-x-1/2 text-center"
      >
        <p className="text-sm mb-2 text-gray-400">Scroll Down</p>
        <ArrowDown className="mx-auto animate-bounce" size={20} />
      </motion.div>
      
      <div className="absolute bottom-0 left-0 w-full h-24 bg-gradient-to-t from-dark-900 to-transparent pointer-events-none" />
    </motion.section>
  );
};

export default Hero;