import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Code, PenTool, Database, LayoutGrid, Globe, Cpu } from 'lucide-react';

const skills = [
  {
    title: 'Frontend Development',
    icon: <Code size={24} />,
    description: 'Creating responsive and interactive user interfaces with modern frameworks.',
    technologies: ['React', 'Vue', 'Angular', 'TypeScript', 'Tailwind CSS']
  },
  {
    title: 'UI/UX Design',
    icon: <PenTool size={24} />,
    description: 'Designing intuitive and aesthetically pleasing user experiences.',
    technologies: ['Figma', 'Adobe XD', 'Sketch', 'Prototyping', 'Wireframing']
  },
  {
    title: 'Backend Development',
    icon: <Database size={24} />,
    description: 'Building robust server-side applications and APIs.',
    technologies: ['Node.js', 'Express', 'Django', 'MongoDB', 'PostgreSQL']
  },
  {
    title: 'Web Animation',
    icon: <LayoutGrid size={24} />,
    description: 'Creating engaging animations and interactive elements.',
    technologies: ['GSAP', 'Framer Motion', 'Three.js', 'WebGL', 'CSS Animations']
  },
  {
    title: 'Full Stack Development',
    icon: <Globe size={24} />,
    description: 'End-to-end development from concept to deployment.',
    technologies: ['MERN Stack', 'Next.js', 'GraphQL', 'REST APIs', 'AWS']
  },
  {
    title: '3D Development',
    icon: <Cpu size={24} />,
    description: 'Building immersive 3D experiences for the web.',
    technologies: ['Three.js', 'React Three Fiber', 'Blender', 'WebGL', '3D Modeling']
  }
];

const Skills: React.FC = () => {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5, ease: "easeOut" },
    },
  };

  return (
    <section id="skills" className="section-padding bg-dark-800">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="inline-block text-sm uppercase tracking-wider text-primary-400 mb-2 font-medium"
          >
            My Expertise
          </motion.span>
          
          <motion.h2
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl font-display font-bold mb-4"
          >
            Skills & Technologies
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            viewport={{ once: true }}
            className="max-w-2xl mx-auto text-gray-300"
          >
            I specialize in a range of technologies and skills that allow me to create comprehensive digital solutions for various needs.
          </motion.p>
        </div>
        
        <motion.div
          ref={ref}
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
          variants={containerVariants}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {skills.map((skill, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="bg-dark-700 p-6 rounded-lg border border-dark-600 hover:border-primary-500 transition-all duration-300 hover:shadow-lg hover:shadow-primary-500/10 group"
            >
              <div className="w-12 h-12 bg-primary-500/10 rounded-lg flex items-center justify-center mb-4 text-primary-400 group-hover:bg-primary-500/20 transition-all duration-300">
                {skill.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2">{skill.title}</h3>
              <p className="text-gray-400 mb-4">{skill.description}</p>
              <div className="flex flex-wrap gap-2">
                {skill.technologies.map((tech, idx) => (
                  <span key={idx} className="text-xs bg-dark-600 px-2 py-1 rounded-md text-gray-300">
                    {tech}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Skills;