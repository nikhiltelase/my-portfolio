import React, { useEffect, useRef } from 'react';

const CustomCursor: React.FC = () => {
  const cursorRef = useRef<HTMLDivElement>(null);
  const cursorDotRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const cursor = cursorRef.current;
    const cursorDot = cursorDotRef.current;
    if (!cursor || !cursorDot) return;
    
    let mouseX = 0;
    let mouseY = 0;
    let cursorX = 0;
    let cursorY = 0;
    let dotX = 0;
    let dotY = 0;
    
    const handleMouseMove = (e: MouseEvent) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
    };
    
    const renderCursor = () => {
      // Add smooth easing to cursor movement
      const easing = 0.1;
      
      // Main cursor
      cursorX += (mouseX - cursorX) * easing;
      cursorY += (mouseY - cursorY) * easing;
      
      // Dot cursor (follows with delay)
      const dotEasing = 0.2;
      dotX += (cursorX - dotX) * dotEasing;
      dotY += (cursorY - dotY) * dotEasing;
      
      if (cursor && cursorDot) {
        cursor.style.transform = `translate(${cursorX}px, ${cursorY}px)`;
        cursorDot.style.transform = `translate(${dotX}px, ${dotY}px)`;
      }
      
      requestAnimationFrame(renderCursor);
    };
    
    window.addEventListener('mousemove', handleMouseMove);
    requestAnimationFrame(renderCursor);
    
    // Show cursor only on desktop
    if (window.innerWidth > 768) {
      cursor.style.display = 'block';
      cursorDot.style.display = 'block';
    } else {
      cursor.style.display = 'none';
      cursorDot.style.display = 'none';
    }
    
    // Add magnetic effect on links and buttons
    const handleMagneticMove = (e: MouseEvent, element: Element) => {
      const rect = element.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      
      const distance = Math.sqrt(
        Math.pow(mouseX - centerX, 2) + Math.pow(mouseY - centerY, 2)
      );
      
      if (distance < 100) {
        const angle = Math.atan2(mouseY - centerY, mouseX - centerX);
        const strength = (100 - distance) / 100;
        const moveX = Math.cos(angle) * strength * 20;
        const moveY = Math.sin(angle) * strength * 20;
        
        (element as HTMLElement).style.transform = `translate(${moveX}px, ${moveY}px)`;
      } else {
        (element as HTMLElement).style.transform = '';
      }
    };
    
    const resetMagnetic = (element: Element) => {
      (element as HTMLElement).style.transform = '';
    };
    
    const magneticElements = document.querySelectorAll('.magnetic-link');
    magneticElements.forEach(element => {
      element.addEventListener('mousemove', (e) => handleMagneticMove(e, element));
      element.addEventListener('mouseleave', () => resetMagnetic(element));
    });
    
    // Add hover effect on interactive elements
    const handleLinkHover = () => {
      cursor.classList.add('scale-[2.5]');
      cursorDot.classList.add('opacity-0');
    };
    
    const handleLinkLeave = () => {
      cursor.classList.remove('scale-[2.5]');
      cursorDot.classList.remove('opacity-0');
    };
    
    const links = document.querySelectorAll('a, button');
    links.forEach(link => {
      link.addEventListener('mouseenter', handleLinkHover);
      link.addEventListener('mouseleave', handleLinkLeave);
    });
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      magneticElements.forEach(element => {
        element.removeEventListener('mousemove', (e) => handleMagneticMove(e, element));
        element.removeEventListener('mouseleave', () => resetMagnetic(element));
      });
      links.forEach(link => {
        link.removeEventListener('mouseenter', handleLinkHover);
        link.removeEventListener('mouseleave', handleLinkLeave);
      });
    };
  }, []);
  
  return (
    <>
      <div 
        ref={cursorRef} 
        className="custom-cursor hidden transition-all duration-150 ease-out"
      />
      <div
        ref={cursorDotRef}
        className="custom-cursor hidden w-1 h-1 bg-white transition-all duration-150 ease-out"
      />
    </>
  );
};

export default CustomCursor;