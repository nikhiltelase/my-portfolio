import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';

const Loader: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const counterRef = useRef<HTMLDivElement>(null);
  const progressRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const container = containerRef.current;
    const text = textRef.current;
    const counter = counterRef.current;
    const progress = progressRef.current;
    
    if (!container || !text || !counter || !progress) return;
    
    // Split text
    const textContent = text.textContent || "";
    text.textContent = "";
    
    textContent.split('').forEach((letter) => {
      const span = document.createElement('span');
      span.textContent = letter;
      span.style.opacity = "0";
      span.style.display = 'inline-block';
      text.appendChild(span);
    });
    
    let currentValue = 0;
    const duration = 30; // Duration in frames
    
    gsap.to(text.children, {
      opacity: 1,
      stagger: 0.05,
      duration: 0.5,
      ease: "power3.out"
    });
    
    const updateCounter = () => {
      if (currentValue < 100) {
        currentValue += 1;
        counter.textContent = currentValue.toString();
        
        if (progress) {
          progress.style.width = `${currentValue}%`;
        }
        
        requestAnimationFrame(updateCounter);
      }
    };
    
    setTimeout(() => {
      requestAnimationFrame(updateCounter);
    }, 400);
    
  }, []);
  
  return (
    <div ref={containerRef} className="fixed inset-0 bg-dark-950 flex flex-col items-center justify-center z-50">
      <div className="relative mb-8">
        <div ref={textRef} className="text-4xl md:text-5xl font-display font-bold gradient-text">
          Nikhil Telase
        </div>
      </div>
      
      <div className="w-64 h-1 bg-dark-700 rounded-full overflow-hidden">
        <div 
          ref={progressRef} 
          className="h-full bg-gradient-to-r from-primary-500 to-secondary-500 w-0"
        />
      </div>
      
      <div ref={counterRef} className="text-lg mt-4">
        0
      </div>
      
      <div className="absolute bottom-8 text-sm text-gray-500">
        Building something amazing...
      </div>
    </div>
  );
};

export default Loader;