import React, { useEffect, useRef } from 'react';
import { motion, useInView, useAnimation } from 'framer-motion';

const About: React.FC = () => {
  const controls = useAnimation();
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });
  
  useEffect(() => {
    if (isInView) {
      controls.start('visible');
    }
  }, [controls, isInView]);
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.6, ease: "easeOut" },
    },
  };

  return (
    <section id="about" className="relative section-padding bg-dark-900">
      <div className="absolute inset-0 z-[-1]">
        <div className="absolute top-0 right-0 w-1/3 h-1/3 bg-accent-500/10 rounded-full filter blur-[80px]" />
      </div>
      
      <div className="max-w-6xl mx-auto">
        <motion.div
          ref={ref}
          initial="hidden"
          animate={controls}
          variants={containerVariants}
          className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
        >
          <motion.div variants={itemVariants} className="relative">
            <div className="relative overflow-hidden rounded-lg">
              <div className="absolute inset-0 bg-gradient-to-tr from-primary-600/40 to-transparent z-10" />
              <img 
                src="https://images.pexels.com/photos/7688336/pexels-photo-7688336.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Nikhil Telase" 
                className="w-full h-auto object-cover transform hover:scale-105 transition-transform duration-700"
              />
            </div>
            <div className="absolute -bottom-5 -right-5 w-24 h-24 bg-primary-500 rounded-lg z-[-1]" />
            <div className="absolute -top-5 -left-5 w-24 h-24 border-2 border-accent-500 rounded-lg z-[-1]" />
          </motion.div>
          
          <div>
            <motion.span 
              variants={itemVariants}
              className="inline-block text-sm uppercase tracking-wider text-primary-400 mb-2 font-medium"
            >
              About Me
            </motion.span>
            
            <motion.h2
              variants={itemVariants}
              className="text-3xl md:text-4xl font-display font-bold mb-6"
            >
              Creative Developer with a Passion for Design
            </motion.h2>
            
            <motion.p variants={itemVariants} className="text-gray-300 mb-4">
              Hello! I'm Nikhil Telase, a passionate software developer and designer focused on creating beautiful, functional digital experiences. With expertise in both front-end and back-end technologies, I build applications that are not just visually appealing but also perform exceptionally well.
            </motion.p>
            
            <motion.p variants={itemVariants} className="text-gray-300 mb-6">
              My approach combines technical expertise with creative design thinking. I believe great products emerge from the perfect balance of aesthetics, functionality, and performance. When I'm not coding, you can find me exploring new design trends, contributing to open-source projects, or experimenting with emerging technologies.
            </motion.p>
            
            <motion.div variants={itemVariants} className="grid grid-cols-2 gap-4 mb-8">
              <div>
                <h3 className="text-xl font-semibold mb-2">Education</h3>
                <p className="text-gray-400">B.Tech in Computer Science</p>
                <p className="text-gray-400">IIT Bombay</p>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Experience</h3>
                <p className="text-gray-400">5+ Years</p>
                <p className="text-gray-400">Full Stack Development</p>
              </div>
            </motion.div>
            
            <motion.a
              variants={itemVariants}
              href="#contact"
              className="inline-flex items-center btn-primary"
            >
              Let's Connect
            </motion.a>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default About;