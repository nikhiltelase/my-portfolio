import React, { useRef, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Points, PointMaterial } from '@react-three/drei';
import * as THREE from 'three';

function generateRandomSpherePoints(count: number, radius: number) {
  const points = new Float32Array(count * 3);
  
  for (let i = 0; i < count; i++) {
    const i3 = i * 3;
    const phi = Math.random() * Math.PI * 2;
    const costheta = Math.random() * 2 - 1;
    const theta = Math.acos(costheta);
    
    const r = radius * Math.cbrt(Math.random());
    
    points[i3] = r * Math.sin(theta) * Math.cos(phi);
    points[i3 + 1] = r * Math.sin(theta) * Math.sin(phi);
    points[i3 + 2] = r * Math.cos(theta);
  }
  
  return points;
}

const ParticleField = () => {
  const pointsRef = useRef<THREE.Points>(null);
  const { mouse, viewport } = useThree();
  const particlesCount = 5000;
  const particleSize = 0.015;
  
  const positions = React.useMemo(() => {
    return generateRandomSpherePoints(particlesCount, 4);
  }, [particlesCount]);
  
  useFrame((state) => {
    if (!pointsRef.current) return;
    
    // Rotate slowly
    pointsRef.current.rotation.x = state.clock.getElapsedTime() * 0.05;
    pointsRef.current.rotation.y = state.clock.getElapsedTime() * 0.08;
    
    // Move slightly based on mouse position
    pointsRef.current.position.x = mouse.x * 0.1;
    pointsRef.current.position.y = mouse.y * 0.1;
  });
  
  return (
    <Points ref={pointsRef} positions={positions} stride={3}>
      <PointMaterial
        transparent
        color="#3b82f6"
        size={particleSize}
        sizeAttenuation
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </Points>
  );
};

const BackgroundCanvas: React.FC = () => {
  return (
    <Canvas camera={{ position: [0, 0, 5], fov: 40 }}>
      <ambientLight intensity={0.1} />
      <ParticleField />
    </Canvas>
  );
};

export default BackgroundCanvas;