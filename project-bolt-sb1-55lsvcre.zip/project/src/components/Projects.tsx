import React, { useState, useRef } from 'react';
import { motion, AnimatePresence, useInView } from 'framer-motion';
import { ExternalLink, Github, X } from 'lucide-react';

const projects = [
  {
    id: 1,
    title: 'Modern E-Commerce Platform',
    category: 'Web Development',
    image: 'https://images.pexels.com/photos/6956903/pexels-photo-6956903.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    description: 'A full-stack e-commerce platform built with React, Node.js, and MongoDB. Features include user authentication, product management, shopping cart, and payment integration.',
    technologies: ['React', 'Node.js', 'Express', 'MongoDB', 'Stripe', 'AWS S3'],
    liveLink: '#',
    githubLink: '#',
  },
  {
    id: 2,
    title: '3D Product Configurator',
    category: '3D Development',
    image: 'https://images.pexels.com/photos/7988113/pexels-photo-7988113.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    description: 'An interactive 3D product configurator that allows users to customize products in real-time. Built with Three.js and React Three Fiber.',
    technologies: ['Three.js', 'React Three Fiber', 'React', 'WebGL', 'GSAP'],
    liveLink: '#',
    githubLink: '#',
  },
  {
    id: 3,
    title: 'AI-Powered Content Generator',
    category: 'AI/ML',
    image: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    description: 'A content generation tool that uses AI to create blog posts, social media content, and marketing copy. Integrated with OpenAI API.',
    technologies: ['Next.js', 'TypeScript', 'OpenAI API', 'MongoDB', 'Tailwind CSS'],
    liveLink: '#',
    githubLink: '#',
  },
  {
    id: 4,
    title: 'Personal Finance Dashboard',
    category: 'Web Application',
    image: 'https://images.pexels.com/photos/7681046/pexels-photo-7681046.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    description: 'A comprehensive personal finance dashboard for tracking expenses, income, investments, and financial goals. Features data visualization and budgeting tools.',
    technologies: ['Vue.js', 'Firebase', 'D3.js', 'Vuex', 'Node.js'],
    liveLink: '#',
    githubLink: '#',
  },
  {
    id: 5,
    title: 'Interactive Data Visualization',
    category: 'Data Visualization',
    image: 'https://images.pexels.com/photos/5673500/pexels-photo-5673500.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    description: 'An interactive data visualization project that presents complex datasets in an engaging and intuitive way. Uses D3.js and SVG animations.',
    technologies: ['D3.js', 'JavaScript', 'SVG', 'React', 'CSS Animations'],
    liveLink: '#',
    githubLink: '#',
  },
  {
    id: 6,
    title: 'Social Media Analytics Platform',
    category: 'Web Application',
    image: 'https://images.pexels.com/photos/3861958/pexels-photo-3861958.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    description: 'A social media analytics platform that provides insights and metrics for marketing professionals. Features real-time data updates and comprehensive reporting.',
    technologies: ['React', 'Redux', 'Node.js', 'PostgreSQL', 'Chart.js', 'Socket.io'],
    liveLink: '#',
    githubLink: '#',
  },
];

const Projects: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<number | null>(null);
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });
  
  const openProject = (id: number) => {
    setSelectedProject(id);
    document.body.style.overflow = 'hidden';
  };
  
  const closeProject = () => {
    setSelectedProject(null);
    document.body.style.overflow = 'auto';
  };
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5, ease: "easeOut" },
    },
  };

  return (
    <section id="projects" className="section-padding bg-dark-900">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="inline-block text-sm uppercase tracking-wider text-primary-400 mb-2 font-medium"
          >
            My Work
          </motion.span>
          
          <motion.h2
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl font-display font-bold mb-4"
          >
            Recent Projects
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            viewport={{ once: true }}
            className="max-w-2xl mx-auto text-gray-300"
          >
            Explore my latest work across various domains, from web applications to 3D experiences and interactive visualizations.
          </motion.p>
        </div>
        
        <motion.div
          ref={ref}
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
          variants={containerVariants}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {projects.map((project) => (
            <motion.div
              key={project.id}
              variants={itemVariants}
              className="group cursor-pointer"
              onClick={() => openProject(project.id)}
            >
              <div className="relative overflow-hidden rounded-lg">
                <div className="absolute inset-0 bg-gradient-to-t from-dark-900 via-dark-900/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10 flex items-end">
                  <div className="p-6">
                    <span className="text-xs font-medium uppercase tracking-wider text-primary-400">
                      {project.category}
                    </span>
                    <h3 className="text-xl font-bold mt-1">{project.title}</h3>
                    <p className="text-gray-300 text-sm mt-2 line-clamp-2">{project.description}</p>
                  </div>
                </div>
                <img 
                  src={project.image}
                  alt={project.title}
                  className="w-full h-72 object-cover transform group-hover:scale-110 transition-transform duration-500"
                />
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
      
      {/* Project Modal */}
      <AnimatePresence>
        {selectedProject !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-dark-950/90 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: 'spring', damping: 20 }}
              className="bg-dark-800 rounded-lg w-full max-w-4xl max-h-[90vh] overflow-y-auto custom-scrollbar"
            >
              {projects
                .filter((p) => p.id === selectedProject)
                .map((project) => (
                  <div key={project.id} className="relative">
                    <button
                      onClick={closeProject}
                      className="absolute top-4 right-4 z-20 bg-dark-700/80 rounded-full p-2 hover:bg-primary-600 transition-colors duration-300"
                    >
                      <X size={20} />
                    </button>
                    
                    <div className="relative h-64 md:h-80">
                      <div className="absolute inset-0 bg-gradient-to-t from-dark-800 via-transparent to-transparent z-10" />
                      <img
                        src={project.image}
                        alt={project.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    
                    <div className="p-6 md:p-8">
                      <span className="text-sm font-medium uppercase tracking-wider text-primary-400">
                        {project.category}
                      </span>
                      <h3 className="text-2xl md:text-3xl font-bold mt-2">{project.title}</h3>
                      
                      <p className="text-gray-300 mt-4">{project.description}</p>
                      
                      <div className="mt-6">
                        <h4 className="text-lg font-semibold mb-2">Technologies Used</h4>
                        <div className="flex flex-wrap gap-2">
                          {project.technologies.map((tech, index) => (
                            <span
                              key={index}
                              className="text-sm bg-dark-600 px-3 py-1 rounded-full text-gray-300"
                            >
                              {tech}
                            </span>
                          ))}
                        </div>
                      </div>
                      
                      <div className="mt-8 flex items-center gap-4">
                        <a
                          href={project.liveLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-2 btn-primary"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <ExternalLink size={16} />
                          View Live
                        </a>
                        <a
                          href={project.githubLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-2 px-6 py-3 rounded-md border border-primary-600 text-white font-medium hover:bg-primary-600/10 transition-all duration-300"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <Github size={16} />
                          View Code
                        </a>
                      </div>
                    </div>
                  </div>
                ))}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};

export default Projects;